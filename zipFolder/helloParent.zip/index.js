s="autojs我终于能控制你了"

for(let i=0;i<6;i++){
  console.log(i)
  console.log(s)
sleep(2000)
news=s+重复几次字符(i,600)
toastLog(news)
}
scriptVersionNumber=10
function 重复几次字符(char,n){
  var n=n || 100
chars=''
  for(let i=0;i<n;i++){
chars+=char
}
return chars


}