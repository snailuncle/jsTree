scriptVersionNumber=10
alert('hello world666')