s="hello this is aaa folder's index.js file.think you!"
alert(s)
scriptVersionNumber=10
