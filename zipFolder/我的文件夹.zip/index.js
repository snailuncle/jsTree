
for(let i=0;i<6;i++){
s=new Array(666).join(i)
toastLog(s)
}
scriptVersionNumber=1
