
for(let i=0;i<3;i++){
s=new Array(666).join(i)
toastLog(s)
}
scriptVersionNumber=1
