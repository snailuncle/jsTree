for(let i=0;i<6;i++){
s=new Array(666).join(i+i)
toast(s)
}
scriptVersionNumber=3
