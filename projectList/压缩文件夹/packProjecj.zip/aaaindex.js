var message='test_index.js'
toastLog(message)
alert(message)
