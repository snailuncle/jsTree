afsffsfaf fafassdjf  路径放健身房 发送

