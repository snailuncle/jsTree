var message='script02.js'
toastLog(message)
alert(